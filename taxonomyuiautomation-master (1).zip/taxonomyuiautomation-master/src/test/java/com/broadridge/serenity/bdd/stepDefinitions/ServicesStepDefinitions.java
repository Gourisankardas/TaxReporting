package com.broadridge.serenity.bdd.stepDefinitions;

import com.broadridge.serenity.bdd.steps.ServicesSteps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ServicesStepDefinitions {

        @Steps ServicesSteps servicesSteps;
        
        @When("User enters {string} in client search box and selects the correct client from results")
        public void userEntersInClientSearchBoxAndSelectsTheCorrectClientFromResults(String client) {
                servicesSteps.searchClient(client);
        }

        @And("User clicks Go button")
        public void userClicksGoButton() {
                servicesSteps.clickServicesGoButton();
        }

        @Then("{string} should be listed under Client Services")
        public void shouldBeListedUnderClientServices(String client) {
                servicesSteps.clientSaved(client);
        }

        @When("User selects Value Add {string} option")
        public void userSelectsValueAddOption(String valueAdd) {
                servicesSteps.selectValue(valueAdd);
        }

        @And("User selects Base Type {string}")
        public void userSelectsBaseType(String baseType) {
                servicesSteps.selectValue(baseType);
        }

        @Then("User gets saved successfully message")
        public void userGetsSavedSuccessfullyMessage() {
                servicesSteps.verifySaveMsg();
        }
}
