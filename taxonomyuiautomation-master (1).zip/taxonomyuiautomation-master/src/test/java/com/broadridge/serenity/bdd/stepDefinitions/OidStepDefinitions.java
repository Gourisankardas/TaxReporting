package com.broadridge.serenity.bdd.stepDefinitions;

import com.broadridge.serenity.bdd.steps.OidSteps;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.DataTableType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

import java.util.List;
import java.util.Map;

public class OidStepDefinitions {

    @Steps OidSteps oidSteps;

    @When("User Enter a CUSIP {string}")
    public void userEnterACUSIP(String userCusip) {
        oidSteps.enterCUSIP(userCusip);
    }

    @And("User clicks on GO button")
    public void userClicksOnGOButton() {
        oidSteps.clickOnGOButton();
    }

    @Then("OID page opens")
    public void oidPageOpens() {
        oidSteps.verifyUserIsOnOidPage();
    }

    @Then("User enters Cusip and changes its OTD type from OldOidType to NewOidType")
    public void userEntersCusipAndChangesItsOTDTypeFromOldOidTypeToNewOidType(DataTable cusipDetails) {
        List<Map<String, String>> nameDetail = cusipDetails.asMaps(String.class, String.class);
        for (Map<String, String> cusip : nameDetail) {
            oidSteps.verifyAndClearCUSIPSearchField();
            oidSteps.enterCUSIP(cusip.get("CusipNo"));
            oidSteps.clickOnGOButton();
            //oidSteps.verifyCurrentOidType(cusip.get("OldOidType"), cusip.get("CusipNo"));
            oidSteps.chooseOid(cusip.get("NewOidType"));
            oidSteps.clickSaveChangesButton();
        }
    }
}



