package com.broadridge.serenity.bdd.stepDefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import com.broadridge.serenity.bdd.steps.CrEligibilitySteps;

public class CrEligibilityStepDefinitions {

    @Steps CrEligibilitySteps crEligibilitySteps;

    @When("User selects CR Eligibility header {string}")
    public void userSelectsCREligibilityHeader(String headerTab) {
        crEligibilitySteps.selectHeader(headerTab);
    }

    @Then("there should be a list of SEC Types {string},Description {string},and checkboxes for each")
    public void listOfSECTypesAndDescription(String secType, String desc) {
        crEligibilitySteps.verifyListOfSECTypesAndDescription(secType,desc);
    }
}
