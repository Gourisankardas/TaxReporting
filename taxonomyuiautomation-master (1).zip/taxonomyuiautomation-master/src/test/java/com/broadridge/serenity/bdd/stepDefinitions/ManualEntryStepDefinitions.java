package com.broadridge.serenity.bdd.stepDefinitions;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.Steps;
import com.broadridge.serenity.bdd.steps.AdminSharedSteps;
import com.broadridge.serenity.bdd.steps.ManualEntrySteps;

import java.util.List;
import java.util.Map;

public class ManualEntryStepDefinitions extends PageObject {

     @Steps
    AdminSharedSteps adminSharedSteps;
    @Steps
    ManualEntrySteps manualEntrySteps;

    @Then("all edit fields should be enabled")
    public void allEditFieldsShouldBeEnabled() {
        manualEntrySteps.verifyEditFieldsEnabled();
    }

    @And("Enter the following information")
    public void enterTheFollowingInformation(DataTable dataTable) {

        List<Map<String, String>> entry = dataTable.asMaps(String.class, String.class);
        for (Map<String, String> value : entry) {
            manualEntrySteps.enterCusip(value.get("Cusip"));
            manualEntrySteps.populateNonReqTxtFields(value.get("Text"));
            manualEntrySteps.enterDt("EffectiveDate", value.get("effectiveDate"));
            manualEntrySteps.enterDt("DeletionDate", value.get("deletionDate"));
            manualEntrySteps.enterDt("EndDate", value.get("endDate"));
            manualEntrySteps.enterBpsID(value.get("bpsId"));
            manualEntrySteps.selectStatus(value.get("statusDropdown"));
            manualEntrySteps.selectSecurityType(value.get("securityTypeDropdown"));
           // manualEntrySteps.dropdownSelection(value.get("securityTypeDropdown"),"SecTypeCode");
        }

    }

    @And("Enters {string} for CUSIP")
    public void entersForCUSIP(String cusip) {
        manualEntrySteps.enterCusip(cusip);
    }

    @And("Enters {string} for other text fields")
    public void entersForOtherTextFields(String txt) {
        manualEntrySteps.populateNonReqTxtFields(txt);
    }

    @And("Enters {string} for effective date")
    public void entersTodaySDateForEffectiveDate(String date) {
        manualEntrySteps.enterDt("EffectiveDate",date);
    }

    @And("Enters {string} for deletion date")
    public void entersNextYearForDeletionDate(String date) {
        manualEntrySteps.enterDt("DeletionDate",date);
    }

    @And("Enters {string} for end date")
    public void entersNextYearForEndDate(String date) {
        manualEntrySteps.enterDt("EndDate",date);
    }

    @And("Enters {string} for BPS ID")
    public void entersForBPSID(String idNumber) {
        manualEntrySteps.enterBpsID(idNumber);
    }

/*    @And("selects {string} from Status dropdown")
    public void selectsFromActiveDropdown(String fieldValue) {
        manualEntrySteps.dropdownSelection(fieldValue,"Active");
    }

    @And("selects {string} from Security Type dropdown")
    public void selectsFromSecTypeDropdown(String fieldValue) {
        manualEntrySteps.dropdownSelection(fieldValue,"Security Type");
    }*/

    @Then("User should be redirected to Cusip Details page for CUSIP {string}")
    public void userShouldBeRedirectedToCusipDetailsPage(String cusip) {
        manualEntrySteps.verifyCusipDetails(cusip);
    }

    @And("CUSIP Details {string} tabs are loaded")
    public void tabsAreLoaded(String tabs) {
        manualEntrySteps.verifyCusipDetailsTabs(tabs);
    }

    @When("User searches for CUSIP {string} after manual entry")
    public void userSearchesForCUSIPAfterManualEntry(String cusip){
        adminSharedSteps.globalSearch(cusip);
    }

    @And("Clicks Edit on Tax Reporting Tab")
    public void clicksEditOnTaxReportingTab() {
        manualEntrySteps.clickEditOnTaxReportingTab();
    }

    @Then("Year End Form Information section is enabled")
    public void yearEndFormInformationSectionIsEnabled() {
        manualEntrySteps.dropdownListSelection("YearEnd");
    }

    @And("Security Information section is enabled")
    public void securityInformationSectionIsEnabled() {
        manualEntrySteps.dropdownListSelection("SecInfo");
    }

    @And("Linked Cusips section is enabled")
    public void linkedCusipsSectionIsEnabled() {
        manualEntrySteps.linkedCusipsLinkEnabled();
    }


    @Then("Message Box appears with successful saved data message")
    public void messageBoxAppearsWithSuccessfulSavedDataMessage() {
        manualEntrySteps.verifySavedMsg();
    }

    @And("User clicks on {string} from CUSIP Details tab")
    public void userClicksOnFromCUSIPDetailsTab(String cusipDetailsHeaderSelection) {
        manualEntrySteps.selectCusipDetailsHeader(cusipDetailsHeaderSelection);
    }

    @Then("Add Tax year, Save, Cancel  buttons are enabled")
    public void addTaxYearSaveCancelButtonsAreEnabled() {
        manualEntrySteps.buttonsEnabled("Add Tax Year","Save","Cancel");
    }

    @And("Add Service Code button is disabled")
    public void addServiceCodeButtonIsDisabled() {
        manualEntrySteps.buttonDisabled("Add Service Code");
    }

    @When("User clicks Add Tax Year")
    public void userClicksAddTaxYear() {
        manualEntrySteps.clickButton("Add Tax Year");
    }

    @Then("Enter a Tax Year pop up appears")
    public void enterATaxYearPopUpAppears() {
        manualEntrySteps.checkPopUpLabel();
    }

    @When("User enters {string} and clicks OK")
    public void userEntersAndClicksOK(String taxyear) throws Exception {
        manualEntrySteps.enterTaxYear(taxyear);
    }

    @Then("Add Service Code button is enabled")
    public void addServiceCodeButtonIsEnabled() {
        manualEntrySteps.buttonsEnabled("Add Service Code");
    }

    @When("User saves {string} and {string} selects {string} from TDS Service Code Dropdown")
    public void userEntersAndSelectsFromTDSServiceCodeDropdown(String stDate, String enDate, String serviceCode) throws Exception {
        manualEntrySteps.fillOutServiceCode(stDate,enDate,serviceCode);
        manualEntrySteps.clickButton("Save");
    }

    @And("TDS Codes has {string}, {string},{string},{string} displayed")
    public void tdsCodesDisplayed(String serviceCode, String taxyear, String stDate, String enDate) {
        manualEntrySteps.verifyTdsServiceCd(serviceCode,taxyear,stDate,enDate);
    }

    @And("User clicks TDS Codes Add button")
    public void userClicksTDSCodesAddButton() {
        manualEntrySteps.clickTDSCodesAddButton();
    }

    @When("User enters {string} into taxation country section")
    public void userEntersIntoTaxationCountrySection(String country) {
            manualEntrySteps.enterTaxationCountry(country);
    }

    @When("User clicks Add button")
    public void userClicksAddButton() {
        manualEntrySteps.clickAddButton();
    }

    @And("User clicks Save button")
    public void userClicksSaveButton() {
        manualEntrySteps.clickSaveButton();
    }

    @And("user clicks on edit button")
    public void userClicksOnEditButton() {
        manualEntrySteps.clickEditButton();
    }
}
