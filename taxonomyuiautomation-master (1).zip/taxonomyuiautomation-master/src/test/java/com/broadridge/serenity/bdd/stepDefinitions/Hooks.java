package com.broadridge.serenity.bdd.stepDefinitions;


import com.broadridge.serenity.bdd.pages.OidPage;
import com.broadridge.serenity.bdd.steps.ApplicationLoginSteps;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;


public class Hooks {
    @Steps
    ApplicationLoginSteps applicationLoginSteps;

    @Steps
    OidPage oidPage;

    @Before
    public void BeforeEachScenario() {

        //Do Nothing
    }

    @After
    public void AfterEachScenario() {


        if (Serenity.sessionVariableCalled("Page").equals("OID")) {

            if (oidPage.oidTypeUserControlCloseButton.isVisible()) {
                oidPage.oidTypeUserControlCloseButton.click();
            }
        }

        applicationLoginSteps.logout();
//                if(S.isFailed())
//        {
//            //Do Nothing
//        }
//        else
//        {
//            als.Logout();
//        }
    }
}