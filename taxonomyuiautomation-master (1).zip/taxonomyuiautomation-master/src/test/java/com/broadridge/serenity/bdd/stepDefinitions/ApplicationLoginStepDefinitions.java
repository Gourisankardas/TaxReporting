package com.broadridge.serenity.bdd.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import com.broadridge.serenity.bdd.steps.AdminSharedSteps;
import com.broadridge.serenity.bdd.steps.ApplicationLoginSteps;

public class ApplicationLoginStepDefinitions
{

    @Steps ApplicationLoginSteps applicationLoginSteps;
    @Steps AdminSharedSteps adminSharedSteps;

    @Given("User is on Application Login Page")
    public void launchURL()
    {
        applicationLoginSteps.openPage();
    }

    @Given("User is on TAXonomy {string} Page")
    public void userIsOnTAXonomyPage(String selectPage){
        launchURL();
        applicationLoginSteps.userLogin();
        applicationLoginSteps.goToTaxonomy();
        adminSharedSteps.goToAdminPage(selectPage);
    }

    @When("User Credentials are Entered")
    public void ApplicationLogin() {
        applicationLoginSteps.userLogin();
    }

    @Given("verify user is on Application Home Page")
    public void verifyUserIsOnApplicationHomePage() {
        applicationLoginSteps.verifyUserIsOnApplicationHomePage();
    }

    public void Logout() {
        applicationLoginSteps.logout();
    }

    @And("navigates to Taxonomy")
    public void navigatesToTaxonomy() {
        applicationLoginSteps.goToTaxonomy();
    }

    @Then("User lands on Taxonomy home page")
    public void userLandsOnTaxonomyHomePage() {
        applicationLoginSteps.verifyUserIsOnTaxonomyHomePage();
    }
}