package com.broadridge.serenity.bdd.stepDefinitions;

import com.broadridge.serenity.bdd.steps.ClientProfileSteps;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ClientProfileStepDefinitions {

    @Steps ClientProfileSteps clientProfileSteps;

    @When("User lands on Client Profile Page")
    public void userLandsOnClientProfilePage() {
        clientProfileSteps.verifyUserLandsOnClientProfilePage();
    }

    @Then("Add Client Profile link is present")
    public void addClientProfileLinkIsPresent() {
        clientProfileSteps.verifyAddClientProfileLinkIsPresent();
    }

    @Then("User Clicks on Add Client Profile Link")
    public void userClicksOnAddClientProfileLink() {
        clientProfileSteps.clickOnAddClientProfileLink();
    }
}
