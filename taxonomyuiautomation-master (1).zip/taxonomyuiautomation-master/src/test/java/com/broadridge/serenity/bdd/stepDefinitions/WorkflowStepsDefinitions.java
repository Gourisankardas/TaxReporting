package com.broadridge.serenity.bdd.stepDefinitions;

import com.broadridge.serenity.bdd.steps.AdminSharedSteps;
import com.broadridge.serenity.bdd.steps.WorkflowSteps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import net.thucydides.core.annotations.Steps;

public class WorkflowStepsDefinitions {

    @Steps AdminSharedSteps adminSharedSteps;
    @Steps WorkflowSteps workflowSteps;

    @Then("Status {string} and values {string} loads")
    public void statusDropdownLoads(String text, String listOfElements) {
        adminSharedSteps.verifyElements(text,listOfElements);
    }

    @And("CUSIP field is present")
    public void cusipFieldIsPresent() {
        workflowSteps.verifyCusipFieldIsPresent();
    }

    @And("verify {string} {string} load")
    public void searchResetButtonsLoad(String text,String listOfElements) {
        adminSharedSteps.verifyElements(text, listOfElements);
    }

    @And("CollapseAll button is present")
    public void collapseAllButtonIsPresent() {
        workflowSteps.verifyCollapseAllButtonIsPresent();
    }

    @And("ExpandAll button is present")
    public void expandAllButtonIsPresent() {
        workflowSteps.verifyExpandAllButtonIsPresent();
    }
}