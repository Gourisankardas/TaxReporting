package com.broadridge.serenity.bdd.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import com.broadridge.serenity.bdd.steps.AdminSharedSteps;
import com.broadridge.serenity.bdd.steps.TriggerAutosysJobsSteps;

public class TriggerAutosysJobsStepDefinitions {

    @Steps
    TriggerAutosysJobsSteps triggerAutosysJobsSteps;

    @Then("table loads with Parser name, current status and action headers")
    public void tableLoadsWithParserNameCurrentStatusAndActionHeaders() {
        triggerAutosysJobsSteps.verifyTableHeaders();
    }

    @And("table values {string}, {string}")
    public void tableValues(String parserName, String statusName) {
        triggerAutosysJobsSteps.verifyTableValues(parserName,statusName);
    }

    @When("User clicks Trigger Job button if Current Status is Success")
    public void userClicksTriggerJobButtonIfIsSuccess() {
        triggerAutosysJobsSteps.ClicksTriggerJobButtonIfSuccess();
    }

    @Then("table values {string}, {string} change")
    public void tableValuesChange(String parserName, String newStatusName) {
        triggerAutosysJobsSteps.verifyTableValues(parserName,newStatusName);
    }

    @And("verify {string} button is {string}")
    public void verifyButtonIs(String triggerJob, String buttonState) {
        triggerAutosysJobsSteps.buttonEnabledDisabled(triggerJob, buttonState );
    }
}
