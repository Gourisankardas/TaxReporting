package com.broadridge.serenity.bdd.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import com.broadridge.serenity.bdd.steps.AdminSharedSteps;
import com.broadridge.serenity.bdd.steps.ApplicationLoginSteps;
import com.broadridge.serenity.bdd.steps.DashboardSteps;

public class DashboardStepDefinitions {

    @Steps ApplicationLoginSteps applicationLoginSteps;
    @Steps AdminSharedSteps adminSharedSteps;
    @Steps DashboardSteps dashboardSteps;

    @When("User lands on Dashboard Page")
    public void userLandsOnPage() {
        applicationLoginSteps.verifyUserLandingPage("Dashboard");
    }

    @Then("verify the text {string} and Source dropdown loads {string}")
    public void verifySourceDropdownLoadsAndText(String text, String listOfElements) {
        adminSharedSteps.verifyElements(text,listOfElements);
    }

    @And("verify {string} in {string} load")
    public void verifyFilterAndResetInButtons(String listOfElements, String text) {
        adminSharedSteps.verifyElements(listOfElements,text);
    }

    @And("Calendar Input fields are present")
    public void calendarInputFieldsIsPresent() {
        dashboardSteps.verifyCalendarInputFieldsIsPresent();
    }

    @When("User selects each {string}")
    public void userSelectsEach(String sourceName)  {
        dashboardSteps.dropdownOptions(sourceName);
    }

    @And("enters {string} in Start Date Field")
    public void entersInStartDateField(String stDate) {
        adminSharedSteps.enterStartDate(stDate);
    }

    @And("enters {string} in End Date field")
    public void entersInEndDateField(String endDate) {
        adminSharedSteps.enterEndDate(endDate);
    }


    @And("user clicks Filter button")
    public void userClicksFilterButton() {
        dashboardSteps.clickFilterButton();
    }

    @Then("User should see results {string} returned")
    public void userShouldSeeResultsReturned(String resultsNum) {
        adminSharedSteps.getRowCount(resultsNum);
    }

    @And("columns should be present if {string} are given")
    public void columnsShouldBePresent(String resultsNum) {
        dashboardSteps.verifyColumns(resultsNum, "File Name:Processed Date:Total Cusips:New Cusips:Cusips Updated:Cusips Deleted/Ignored:Uploaded By:Source: ");
    }

/*    @And("following columns should be present if {string} are given")
    public void followingColumnsShouldBePresentIfAreGiven(String resultsNum, DataTable dataTable) {
        dashboardSteps.verifyColumns1(resultsNum, dataTable);
    }*/


    @And("Source should be {string} except All or no {string}")
    public void sourceShouldBeExceptAll(String option, String rowNum) {
        dashboardSteps.verifyFirstSource(option, rowNum);
    }

}