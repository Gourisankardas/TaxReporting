package com.broadridge.serenity.bdd.stepDefinitions;

import com.broadridge.serenity.bdd.steps.ChangeHistorySteps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import com.broadridge.serenity.bdd.steps.ApplicationLoginSteps;

public class ChangeHistoryStepDefinitions {

    @Steps ApplicationLoginSteps applicationLoginSteps;
    @Steps ChangeHistorySteps changeHistorySteps;

    @When("User lands on {string} Page")
    public void userLandsOnPage(String page) {
        applicationLoginSteps.verifyUserLandingPage(page);
    }

    @And("From date field is present")
    public void fromDateFieldIsPresent() {
        changeHistorySteps.verifyFromDateFieldIsPresent();
    }

    @And("To date field is present")
    public void toDateFieldIsPresent() {
        changeHistorySteps.verifyToDateFieldIsPresent();
    }


}
