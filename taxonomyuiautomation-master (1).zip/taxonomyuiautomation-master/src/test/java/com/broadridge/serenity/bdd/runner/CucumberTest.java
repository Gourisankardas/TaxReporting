package com.broadridge.serenity.bdd.runner;

import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberSerenityRunner;
import org.junit.runner.RunWith;

@RunWith(CucumberSerenityRunner.class)
@CucumberOptions(
       features = "src/test/resources/features/Taxonomy",
        glue = {"com/broadridge/serenity/bdd/stepDefinitions"},
        tags = "@Regression",
        plugin = {
                "pretty",
                "json:build/cucumber-report/cucumber.json",
                "junit:build/cucumber-report/cucumber.xml",
                "html:build/cucumber-report/cucumber.html"}
)
public class CucumberTest {

}