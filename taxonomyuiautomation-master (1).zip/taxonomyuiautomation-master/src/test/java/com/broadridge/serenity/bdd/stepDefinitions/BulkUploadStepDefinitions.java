package com.broadridge.serenity.bdd.stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import com.broadridge.serenity.bdd.steps.BulkUploadSteps;

public class BulkUploadStepDefinitions {

    @Steps BulkUploadSteps bulkUploadSteps;

    @When("User is on {string} Tab")
    public void userIsOnTab(String tabName) {
        bulkUploadSteps.verifySelectedTab(tabName);
    }

    @Then("{string} {string} is available to be selected and downloaded")
    public void isAvailableToBeSelectedAndDownloaded(String tabName, String templateNames) {
        bulkUploadSteps.verifyTemplatesAndDownload(tabName,templateNames);
    }

    @And("Browse button is enabled")
    public void browseButtonIsEnabled() {
        bulkUploadSteps.browseButtonEnabled();
    }

    @And("Upload button is enabled")
    public void uploadButtonIsEnabled() {
        bulkUploadSteps.uploadButtonEnabled();
    }

    @And("Browse and Upload {string} against {string} in {string} Tab")
    public void browseAndUploadAgainstInTab(String templateFiles, String templateNames, String tabName) {
        bulkUploadSteps.browseAndUploadTemplateAndVerify(templateFiles, templateNames, tabName);
    }

    @And("delete the downloaded templates")
    public void deleteTheDownloadedTemplates() {
        bulkUploadSteps.deleteDirectory();
    }
}
