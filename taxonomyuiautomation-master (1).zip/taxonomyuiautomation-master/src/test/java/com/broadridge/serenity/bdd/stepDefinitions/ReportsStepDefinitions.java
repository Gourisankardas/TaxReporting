package com.broadridge.serenity.bdd.stepDefinitions;

import com.broadridge.serenity.bdd.steps.ReportsSteps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;

public class ReportsStepDefinitions {

    @Steps ReportsSteps reportsSteps;

    @When("User selects {string}")
    public void userSelectsExternalReports(String reports) {
        reportsSteps.linkSelect(reports);
    }

    @Then("Tax Year is selected to Current Tax year {string}")
    public void taxYearIsSelectedToCurrentTaxYear(String usrTaxyr) {
        reportsSteps.taxYrConfirmation(usrTaxyr);
    }

    @And("All {string} reports {string} are loaded.")
    public void allReportsAreLoaded(String reports, String reportNames) {
        reportsSteps.reportsLoaded(reports,reportNames);
    }

}
