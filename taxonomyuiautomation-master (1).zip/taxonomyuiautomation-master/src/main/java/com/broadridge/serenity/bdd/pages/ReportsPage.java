package com.broadridge.serenity.bdd.pages;


import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;


public class ReportsPage extends PageObject {

    public static final String reportsHomePageURL = "https://icsqa-taxonomy.broadridge.net/Reports/Reports.aspx";

    @FindBy(xpath = "//a[contains(text(),'TAXonomy')]")
    public WebElementFacade taxonomyHeader;

    @FindBy(xpath = "//select[@id=\"ctl00_MainContent_ddlTaxYear\"]")
    public WebElementFacade taxYear;

    @FindBy(xpath = "//a[contains(text(),'Reports')]")
    public WebElementFacade reports;

}
