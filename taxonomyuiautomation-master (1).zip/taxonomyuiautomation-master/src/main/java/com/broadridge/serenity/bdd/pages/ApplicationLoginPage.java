package com.broadridge.serenity.bdd.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class ApplicationLoginPage extends PageObject {

    public static final String tAXonomyHomePageURL = "https://icsqa-taxonomy.broadridge.net/Default.aspx";

    @FindBy(xpath = "//input[@id='USER']")
    public WebElementFacade EmailUserId;

    @FindBy(xpath = "//input[@id='PASSWORD']")
    public WebElementFacade Password;

    @FindBy(xpath = "//button[@id='submit_btn']")
    public WebElementFacade SubmitBtn;

/*    @FindBy(xpath = "//a[@id='liLogoff']")
    public WebElementFacade SignOutBtn;*/

    @FindBy(xpath = "//span[text()=\"Tax Reporting\"]")
    public WebElementFacade TaxReportingLink;

    @FindBy(xpath = "//td[@id=\"ctl00_mainMenun11\"]")
    public WebElementFacade TaxonomyLink;

    @FindBy(xpath = "//a[contains(text(),'Logoff') or contains(text(),'Log Off')]")
    public WebElementFacade LogoffBtn;
}
