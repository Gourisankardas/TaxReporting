package com.broadridge.serenity.bdd.enums;

public enum PARAMETER {
    FORM, QUERY, NONE, PATH
}
