package com.broadridge.serenity.bdd.steps;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.AdminSharedPage;
import com.broadridge.serenity.bdd.pages.DashboardPage;
import com.broadridge.serenity.bdd.pages.ReportsPage;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.openqa.selenium.By;
import org.openqa.selenium.interactions.Actions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;
import static com.broadridge.serenity.bdd.pages.ClientProfilePage.clientProfileHomePageURL;
import static com.broadridge.serenity.bdd.pages.CrEligibilityPage.crEligibilityHomePageURL;
import static com.broadridge.serenity.bdd.pages.OidPage.oidHomePageURL;
import static com.broadridge.serenity.bdd.pages.ReportsPage.reportsHomePageURL;
import static com.broadridge.serenity.bdd.pages.ServicesPage.servicesHomePageURL;
import static com.broadridge.serenity.bdd.pages.TriggerAutosysJobsPage.triggerAutosysJobsHomePageURL;
import static com.broadridge.serenity.bdd.commonpages.Utils.mouseHover;

public class AdminSharedSteps extends ScenarioSteps {

    @Steps
    AdminSharedPage adminSharedPage;

    @Steps
    ReportsPage reportsPage;

    @Steps
    DashboardPage dashboardPage;

    @Step
    public void goToAdminPage(String selectPage) {
        Serenity.setSessionVariable("Page").to(selectPage);

        if (selectPage.equals("Reports")) {
            mouseHover(getDriver(), reportsPage.taxonomyHeader);
            waitABit(3000);
            reportsPage.reports.waitUntilClickable().click();

        } else {
            adminSharedPage.admin.waitUntilClickable().click();
            adminSharedPage.selectPage(selectPage).waitUntilClickable().click();
        }
        String expectedPage, actualPage;
        switch (selectPage) {
            case "Services":
                expectedPage = servicesHomePageURL;
                break;
            case "Client Profiles":
                expectedPage = clientProfileHomePageURL;
                break;
            case "CR Eligibiliy":
                expectedPage = crEligibilityHomePageURL;
                break;
            case "Trigger Autosys Job":
                expectedPage = triggerAutosysJobsHomePageURL;
                break;
            case "OID":
                expectedPage = oidHomePageURL;
                break;
            case "Reports":
                expectedPage = reportsHomePageURL;
                break;
            default: {
                selectPage = selectPage.replaceAll("\\s", "");
                expectedPage = "https://icsqa-taxonomy.broadridge.net/Admin/" + selectPage + ".aspx";
            }
        }
        actualPage = getDriver().getCurrentUrl();
        logAndAssert("User verifies landing page", expectedPage, actualPage, AssertType.EQUALS);
    }

    @Step
    public void verifyElements(String text, String listOfElements) {
        List<String> elements = new ArrayList<>(Arrays.asList(listOfElements.split(":")));
        switch (text) {
            case "Dropdown":
                assertElements(elements, text, adminSharedPage.dropdown);
                break;
            case "Buttons":
                assertElements(elements, text, adminSharedPage.pageButtons);
                break;
        }
    }

    @Step("Taxonomy Validating ")
    public void assertElements(List<String> webElementList, String text, List<WebElementFacade> webElements) {
        for (WebElementFacade i : webElements) {
            if (i.getText().length() > 1) {
                logAndAssert("User verifies if " + text + " contains" + i.getText(), true, webElementList.contains(i.getText()), AssertType.EQUALS);
            } else {
                logAndAssert("User verifies if " + text + " contains" + i.getValue(), true, webElementList.contains(i.getValue()), AssertType.EQUALS);
            }
        }
    }


    @Step
    public void enterStartDate(String stDate) {
        adminSharedPage.startDate.waitUntilEnabled().clear();
        adminSharedPage.startDate.waitUntilEnabled().sendKeys(stDate);
        dashboardPage.done.waitUntilClickable().click();
    }

    @Step
    public void enterEndDate(String endDate) {
        adminSharedPage.endDate.waitUntilEnabled().clear();
        adminSharedPage.endDate.waitUntilEnabled().sendKeys(endDate);
        dashboardPage.done.waitUntilClickable().click();
    }

    @Step
    public void getRowCount(String rowNum) {
        if (rowNum.equals("0")) {
            logAndAssert("User verifies 0 records returned", "No records found", adminSharedPage.noRecordsMsg.getText(), AssertType.EQUALS);
        } else {
            logAndAssert("User verifies the number of records returned", rowNum, adminSharedPage.rowCount.getText(), AssertType.EQUALS);
        }
    }

    @Step
    public void globalSearch(String cusip) {
        adminSharedPage.globalSearchBox.waitUntilEnabled().sendKeys(cusip);
        adminSharedPage.goBtn.waitUntilClickable().click();
        adminSharedPage.searchResultEditLink.waitUntilClickable().click();
    }


}
