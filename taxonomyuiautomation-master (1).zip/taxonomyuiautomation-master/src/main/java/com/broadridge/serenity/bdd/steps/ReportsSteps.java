package com.broadridge.serenity.bdd.steps;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.ReportsPage;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.openqa.selenium.By;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;


public class ReportsSteps extends ScenarioSteps {
    @Steps
    ReportsPage reportsPage;

    @Step("User tries to click {0}")
    public void linkSelect(String reportType) {
        WebElementFacade report = reportsPage.$(By.xpath("//a[contains(text(),'" + reportType + "')]"));
        report.waitUntilClickable().click();
    }

    @Step
    public void taxYrConfirmation(String actualUserTaxYear) {
        String expectedUserTaxYear = reportsPage.taxYear.select().getFirstSelectedOption().getAttribute("value");
        logAndAssert("User verifies Tax Year", expectedUserTaxYear, actualUserTaxYear, AssertType.EQUALS);
    }

    @Step
    public void reportsLoaded(String reportType, String reportNames) {
        List<String> reportNamesList = new ArrayList<>(Arrays.asList(reportNames.split(":")));
        String reportXPath = "//ul[@class=\"reports\"]/li/a[contains(@id,'" + reportType + "')]";
        List<WebElementFacade> el = reportsPage.$$(By.xpath(reportXPath));
        System.out.println(el);
        List<String> actualReportNamesList = new ArrayList<>();
        for (WebElementFacade i : el) {
            actualReportNamesList.add(i.getAttribute("innerText"));
        }
        logAndAssert("User verifies if all reports of type " + reportType + " are loaded", reportNamesList, actualReportNamesList, AssertType.LISTARRAYEQUALS);
    }
}