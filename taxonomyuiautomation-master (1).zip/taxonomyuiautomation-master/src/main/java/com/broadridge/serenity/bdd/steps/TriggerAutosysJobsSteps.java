package com.broadridge.serenity.bdd.steps;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.TriggerAutosysJobsPage;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;

public class TriggerAutosysJobsSteps extends ScenarioSteps {
    @Steps
    TriggerAutosysJobsPage triggerAutosysJobsPage;

    @Step
    public void verifyTableHeaders() {
        logAndAssert("User verifies Taxonomy Trigger Autosys Jobs: Parser Name is displayed", true, triggerAutosysJobsPage.parserNameHeader.isDisplayed(), AssertType.EQUALS);
        logAndAssert("User verifies Taxonomy Trigger Autosys Jobs: Current Status is displayed", true, triggerAutosysJobsPage.statusHeader.isDisplayed(), AssertType.EQUALS);
        logAndAssert("User verifies Taxonomy Trigger Autosys Jobs: Action Headers is displayed", true, triggerAutosysJobsPage.actionHeader.isDisplayed(), AssertType.EQUALS);
    }

    @Step
    public void verifyTableValues(String parserName, String statusName) {
        logAndAssert("User verifies Taxonomy Trigger Autosys Jobs Parser Name", parserName, triggerAutosysJobsPage.parserName.getText(), AssertType.EQUALS);
        if (triggerAutosysJobsPage.jobStatus.getText().equals("Success")) {
            logAndAssert("User verifies Taxonomy Trigger Autosys Jobs Status", statusName, triggerAutosysJobsPage.jobStatus.getText(), AssertType.EQUALS);
        } else {
            logAndAssert("User verifies Taxonomy Trigger Autosys Jobs Status", "Started", triggerAutosysJobsPage.jobStatus.getText(), AssertType.EQUALS);
        }

    }

    @Step
    public void buttonEnabledDisabled(String buttonName, String enabledDisabled) {
        Serenity.recordReportData().withTitle("Taxonomy " + buttonName + " is " + enabledDisabled);

        if (enabledDisabled.equals("Enabled")) {
            logAndAssert("User verifies Trigger Job button Disabled status", "false", triggerAutosysJobsPage.triggerJobBtn.getAttribute("aria-disabled"), AssertType.EQUALS);
        } else if (enabledDisabled.equals("Disabled")) {
            logAndAssert("User verifies Trigger Job button Disabled status", "true", triggerAutosysJobsPage.triggerJobBtn.getAttribute("aria-disabled"), AssertType.EQUALS);
        }
    }

    public void ClicksTriggerJobButtonIfSuccess() {
        if (triggerAutosysJobsPage.jobStatus.getText().equals("Success")) {
            triggerAutosysJobsPage.triggerJobBtn.waitUntilClickable().click();
        }
    }
}
