package com.broadridge.serenity.bdd.enums;

public enum AssertType {

    EQUALS, CONTAINS, NOTEQUALS, EQUALSIGNORECASE, MATCHESREGEX, LISTARRAYEQUALS, SIZE
}
