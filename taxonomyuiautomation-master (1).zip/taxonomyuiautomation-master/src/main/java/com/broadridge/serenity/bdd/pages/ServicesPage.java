package com.broadridge.serenity.bdd.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class ServicesPage extends PageObject {

    public static final String servicesHomePageURL = "https://icsqa-taxonomy.broadridge.net/Admin/ClientAddOnServices.aspx";

    @FindBy(xpath = "//input[@id=\"ctl00_ctl00_MainContent_MainContent_txtSearchClient\"]")
    public WebElementFacade ClientInput;

    @FindBy(xpath = "//ul[starts-with(@style,'display: block')]/li[@class=\"ui-menu-item\"]/a")
    public WebElementFacade ClientAutoFill;

    @FindBy(xpath = "//span[@id=\"ctl00_ctl00_MainContent_MainContent_lblClient\"]")
    public WebElementFacade ClientSelected;

    @FindBy(xpath = "//span[@id=\"ctl00_ctl00_MainContent_MainContent_lblMessage\"]")
    public WebElementFacade SaveMsg;

    @FindBy(xpath = "//*[@name='ctl00$ctl00$MainContent$MainContent$btnGo']")
    public WebElementFacade servicesGo;
}
