package com.broadridge.serenity.bdd.steps;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.ManualEntryPage;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.openqa.selenium.Keys;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;

public class ManualEntrySteps extends ScenarioSteps {

    @Steps
    ManualEntryPage manualEntryPage;

    @Step
    public void verifyEditFieldsEnabled() {
        List<String> inputNames = new ArrayList<>();
        List<String> cusipDetailLabels = new ArrayList<>(Arrays.asList("Cusip", "Sedol", "Ticker", "Status", "EffectiveDate", "DeletionDate", "Description", "ISIN", "SecTypeCode", "BPSID", "RecordEndDate"));
        logAndAssert("User checks the number of Manual Entry Fields are as expected ", cusipDetailLabels.size(), manualEntryPage.cusipDetailInputs.size(), AssertType.SIZE);
        for (WebElementFacade e : manualEntryPage.cusipDetailInputs) {
            e.isEnabled();
            String name = e.getAttribute("name");
            inputNames.add(name.substring(42).trim());
        }
        logAndAssert("User verifies if the below editable Fields are present", cusipDetailLabels, inputNames, AssertType.LISTARRAYEQUALS);
    }

    @Step
    public void enterCusip(String cusip) {
        manualEntryPage.cusipInput.waitUntilEnabled().sendKeys(cusip);
    }

    @Step
    public void populateNonReqTxtFields(String txt) {
        for (WebElementFacade e : manualEntryPage.otherTxtFields) {
            e.waitUntilEnabled().sendKeys(txt);
        }
    }

    @Step
    public void enterDt(String dtElement, String date) {
        switch (dtElement) {
            case "DeletionDate":
                manualEntryPage.deletionDateInput.waitUntilEnabled().sendKeys(date);
                break;
            case "EndDate":
                manualEntryPage.endDateInput.waitUntilEnabled().sendKeys(date);
                break;
            case "EffectiveDate":
                manualEntryPage.effectiveDateInput.waitUntilEnabled().sendKeys(date);
        }
    }

    @Step
    public void enterBpsID(String idNumber) {
        manualEntryPage.bpsId.waitUntilEnabled().sendKeys(idNumber);
    }

    @Step
    public void selectStatus(String fieldValue) {
        manualEntryPage.statusField.waitUntilClickable().sendKeys(fieldValue, Keys.ENTER);
    }

    @Step
    public void selectSecurityType(String fieldValue) {
        manualEntryPage.securityTypeField.waitUntilClickable().sendKeys(fieldValue, Keys.ENTER);
    }

    @Step
    public void verifyCusipDetails(String cusip) {
        logAndAssert("User verifies if CUSIP :" + cusip + " is created", "CUSIP DETAILS", manualEntryPage.cusipDetails.getText(), AssertType.EQUALS);
    }

    @Step
    public void verifyCusipDetailsTabs(String tabs) {
        List<String> tabsList = new ArrayList<>(Arrays.asList(tabs.split(":")));
        List<String> tabNames = new ArrayList<>();
        for (WebElementFacade e : manualEntryPage.tabHeaders) {
            tabNames.add(e.getText());
        }
        logAndAssert("User redirected to Cusip Details Page & verifies if the cusip tabs are present", tabNames, tabsList, AssertType.LISTARRAYEQUALS);
    }

    @Step
    public void dropdownListSelection(String partOfPage) {
        LocalDate tomorrowDate = LocalDate.now();
        String tDate = tomorrowDate.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        switch (partOfPage) {
            case "YearEnd":
                loopLabels(manualEntryPage.yearEndLabels, partOfPage, manualEntryPage.yearEndInputs, manualEntryPage.yearEndSpans, 1);
                manualEntryPage.yearEndDateNotification.waitUntilEnabled().sendKeys(tDate);
                break;
            case "SecInfo":
                loopLabels(manualEntryPage.secInfoLabels, partOfPage, manualEntryPage.secInfoInputs, manualEntryPage.secInfoSpans, 8);
                manualEntryPage.secInfoSpecialNoticeTxt.waitUntilEnabled().sendKeys("test");
                manualEntryPage.secInfoProLink.waitUntilEnabled().sendKeys("http://www.Broadridge.com");
                manualEntryPage.secInfoDocLink.waitUntilEnabled().sendKeys("http://www.Broadridge.com");
                break;
        }
    }

    @Step
    public void loopLabels(List<WebElementFacade> listOfLabels, String testingPage, List<WebElementFacade> listOfInputs, List<WebElementFacade> listOfDwnIcons, int startDigit) {
        int j = startDigit;
        logAndAssert("Taxonomy Manual Entry page " + testingPage + " labels match input fields", listOfInputs.size(), (listOfLabels.size() - 1), AssertType.SIZE);

        for (WebElementFacade e : listOfDwnIcons) {
            e.waitUntilClickable().click();
            manualEntryPage.$(By.xpath("//ul[@id='ui-id-" + j + "']/li/a")).waitUntilClickable().click();
            j++;
        }
    }

    @Step
    public void linkedCusipsLinkEnabled() {
        logAndAssert("User verifies Taxonomy Manual Entry Page has Linked CUSIP link enabled", true, manualEntryPage.lnkCusipLink.isEnabled(), AssertType.EQUALS);
    }

    @Step
    public void verifySavedMsg() {
        manualEntryPage.msgBoxTxt.isDisplayed();
        logAndAssert("User checks if Message Box with successful saved data message", "Data saved", manualEntryPage.msgBoxTxt.getText(), AssertType.EQUALS);
        manualEntryPage.msgBoxClose.waitUntilClickable().click();
    }

    @Step
    public void selectCusipDetailsHeader(String cusipDetailsHeaderSelection) {
        String pXpath = "//li[contains(@id,\"ctl00_ctl00_MainContent_li\")]/a[contains(text(),'";
        manualEntryPage.$(By.xpath(pXpath + cusipDetailsHeaderSelection + "')]")).waitUntilClickable().click();
    }

    @Step
    public void buttonsEnabled(String... buttonNames) {
        List<String> bts = new ArrayList<>(Arrays.asList(buttonNames));
        for (String s : bts) {
            Boolean buttonActualStatus = manualEntryPage.$(By.xpath(manualEntryPage.partialXpath + s + "']")).isEnabled();
            logAndAssert("User checks if Taxonomy TDS Code" + s + " is enabled", true, buttonActualStatus, AssertType.EQUALS);
        }
    }

    @Step
    public void buttonDisabled(String buttonName) {
        String xPath = "//button[starts-with(@data-bind,'click:addCusipServiceCode')]";
        String buttonActualStatus = manualEntryPage.$(By.xpath(xPath)).getAttribute("aria-disabled");
        logAndAssert("User checks if Taxonomy TDS Code" + buttonName + " is disabled", "true", buttonActualStatus, AssertType.EQUALS);
    }

    @Step
    public void clickButton(String button) {
        String buttonName = manualEntryPage.partialXpath + button + "']";
        manualEntryPage.$(By.xpath(buttonName)).waitUntilClickable().click();
    }


    @Step
    public void checkPopUpLabel() {
        logAndAssert("User checks Pop-Up Label", "Enter a Tax Year:", manualEntryPage.enterTaxYrLabel.getText(), AssertType.EQUALS);
    }

    @Step
    public void enterTaxYear(String taxyear) {
        manualEntryPage.taxYear.waitUntilEnabled().sendKeys(taxyear);
        manualEntryPage.taxYrOkBtn.waitUntilClickable().click();
    }

    @Step
    public void fillOutServiceCode(String stDate, String enDate, String serviceCode) {
        manualEntryPage.tdsServiceCd.selectByVisibleText(serviceCode);
        manualEntryPage.startDate.waitUntilEnabled().sendKeys(stDate);
        manualEntryPage.endDate.waitUntilEnabled().sendKeys(enDate);
        manualEntryPage.endDateHeader.waitUntilClickable().click();
    }

    @Step
    public void verifyTdsServiceCd(String serviceCode, String taxyear, String stDate, String enDate) {
        List<String> headerTxt = new ArrayList<>(Arrays.asList("TDS Service Code", "Tax Year", "Start Date", "End Date"));
        List<String> userInput = new ArrayList<>(Arrays.asList(serviceCode, taxyear, stDate, enDate));

        for (int i = 0; i < manualEntryPage.tdsCodesHeader.size(); i++) {
            logAndAssert("User checks TAxonomy: TDS Codes header tabs", headerTxt.get(i), manualEntryPage.tdsCodesHeader.get(i).getText(), AssertType.EQUALS);
        }
        for (int i = 0; i < manualEntryPage.tdsCodesSavedEntries.size(); i++) {
            logAndAssert("User checks TDS codes saved entries are displayed", userInput.get(i), manualEntryPage.tdsCodesSavedEntries.get(i).getText(), AssertType.EQUALS);
        }
    }

    @Step
    public void enterTaxationCountry(String country) {
        manualEntryPage.taxationCountryInput.waitUntilEnabled().clear();
        manualEntryPage.taxationCountryInput.waitUntilEnabled().sendKeys(country);
    }

    @Step
    public void clickAddButton() {
        manualEntryPage.add.waitUntilClickable().click();
    }

    @Step
    public void clickSaveButton() {
        manualEntryPage.save.waitUntilClickable().click();
    }

    @Step
    public void clickEditOnTaxReportingTab() {
        manualEntryPage.edit.waitUntilClickable().click();
    }

    public void clickEditButton() {
        manualEntryPage.edit1.waitUntilClickable().click();
    }

    public void clickTDSCodesAddButton() {
        manualEntryPage.addButtonTdsCodes.waitUntilClickable().click();
    }
}
