package com.broadridge.serenity.bdd.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class WorkflowPage extends PageObject {

    @FindBy(xpath = "//option[@value=\"N\"]")
    public WebElementFacade New;

/*    @FindBy(xpath = "//option[@value=\"A\"]")
    public WebElementFacade Accepted;

    @FindBy(xpath = "//option[@value=\"R\"]")
    public WebElementFacade Rejected;*/

    @FindBy(xpath = "//option[@value=\"H\"]")
    public WebElementFacade Hold;

    @FindBy(xpath = "//div/fieldset/p/input[contains(@id,'CUSIP')]")
    public WebElementFacade cusip;

    @FindBy(xpath = "//input[@id=\"ctl00_MainContent_btnSubmit\"]")
    public WebElementFacade SearchBtn;

    @FindBy(xpath = "//a[@id=\"collapseAll\"]")
    public WebElementFacade collapseAll;

    @FindBy(xpath = "//a[@id=\"expandAll\"]")
    public WebElementFacade expandAllBtn;
}

