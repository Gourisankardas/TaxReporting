package com.broadridge.serenity.bdd.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class OidPage extends PageObject {

    public static final String oidHomePageURL = "https://icsqa-taxonomy.broadridge.net/OID/OIDLandingPage.aspx";

    @FindBy(xpath = "//input[@name=\"ctl00$MainContent$txtCusip\"]")
    public WebElementFacade cusip;

    @FindBy(xpath = "//select[contains(@id,'ddlOIDType')]")
    public WebElementFacade oidList;

    @FindBy(xpath = "//*[@name='ctl00$MainContent$btnSearchCusip']")
    public WebElementFacade oidGo;

    @FindBy(xpath = "//input[contains(@value,'Save Changes')]")
    public WebElementFacade oidSaveChanges;

    @FindBy(xpath = "//button[contains(text(),'Close')]")
    public WebElementFacade oidTypeUserControlCloseButton;

}
