package com.broadridge.serenity.bdd.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class TriggerAutosysJobsPage extends PageObject {

    public static final String triggerAutosysJobsHomePageURL = "https://icsqa-taxonomy.broadridge.net/Admin/TriggerAutoSysJobs.aspx";


    @FindBy(xpath = "//tr[@class=\"headerNoSort\"]/th[1]")
    public WebElementFacade parserNameHeader;

    @FindBy(xpath = "//tr[@class=\"headerNoSort\"]/th[2]")
    public WebElementFacade statusHeader;

    @FindBy(xpath = "//tr[@class=\"headerNoSort\"]/th[1]")
    public WebElementFacade actionHeader;

    @FindBy(xpath = "//table[@class=\"tbl\"]/tbody/tr[not(@class='headerNoSort')][1]/td/span[@class=\"ParserName\"]")
    public WebElementFacade parserName;

    @FindBy(xpath = "//span[contains(@class,'JobStatus')]")
    public WebElementFacade jobStatus;

    @FindBy(xpath = "//input[@type=\"submit\" and @value=\"Trigger Job\" and not(@style=\"display:none;\")]")
    public WebElementFacade triggerJobBtn;


}
