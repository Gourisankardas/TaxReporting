package com.broadridge.serenity.bdd.steps;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.ApplicationLoginPage;
import com.broadridge.serenity.bdd.pages.OidPage;
import helpers.BaseDecodeHelper;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;
import static com.broadridge.serenity.bdd.pages.ApplicationLoginPage.tAXonomyHomePageURL;

public class ApplicationLoginSteps extends ScenarioSteps {

    @Steps
    ApplicationLoginPage applicationLoginPage;
    @Steps
    OidPage oidPage;
    EnvironmentVariables variables = SystemEnvironmentVariables.createEnvironmentVariables();

    @Step
    public void openPage() {
        applicationLoginPage.open();
        getDriver().manage().window().maximize();
        logAndAssert("User verifies if Application login page is displayed", true, applicationLoginPage.EmailUserId.isDisplayed(), AssertType.EQUALS);
    }

    @Step
    public void userLogin() {
        applicationLoginPage.EmailUserId.sendKeys(new String(BaseDecodeHelper.getDecoder().decode(variables.getProperty("application.userName"))));
        applicationLoginPage.Password.sendKeys(new String(BaseDecodeHelper.getDecoder().decode(variables.getProperty("application.password"))));
        applicationLoginPage.SubmitBtn.waitUntilClickable().click();
    }

    @Step
    public void logout() {
        String myAppsScreenUrl = "https://icsqa-myservice.broadridge.net/UniversalPortal/AppSelector/ChooseApp.aspx";

        if (oidPage.getDriver().getCurrentUrl().equalsIgnoreCase(myAppsScreenUrl)) {
            applicationLoginPage.SubmitBtn.waitUntilClickable().click();
        } else {
            applicationLoginPage.LogoffBtn.waitUntilClickable().click();
        }
        logAndAssert("User verifies if Universal Portal Home Page is not displayed after logout: ", true, applicationLoginPage.EmailUserId.isPresent(), AssertType.EQUALS);
    }

    @Step("User tries to click on Tax Reporting Link")
    public void goToTaxonomy() {
//        applicationLoginPage.TaxReportingLink.waitUntilClickable().click();
//        applicationLoginPage.TaxonomyLink.waitUntilClickable().click();
//        applicationLoginPage.TaxonomyLink.waitUntilClickable().click();
        applicationLoginPage.getDriver().get(variables.getProperty("url.taxonomy"));
    }

    @Step
    public void verifyUserLandingPage(String givenPage) {
        String currentUrl = getDriver().getCurrentUrl();
        givenPage = givenPage.replaceAll("\\s", "");
        String expectedUrl = "https://icsqa-taxonomy.broadridge.net/Admin/" + givenPage + ".aspx";
        waitABit(10);
        logAndAssert("User verifies if landing Page is :" + givenPage, expectedUrl, currentUrl, AssertType.EQUALS);
    }

    @Step("verify user is on Application Home Page")
    public void verifyUserIsOnApplicationHomePage() {
        String expectedUrl = variables.getProperty("webdriver.base.url");
        String homePageUrl = getDriver().getCurrentUrl();
        logAndAssert("User verifies Universal Portal Home Page URL", expectedUrl, homePageUrl, AssertType.EQUALS);
    }

    @Step
    public void verifyUserIsOnTaxonomyHomePage() {
        String taxonomyHomeUrl = getDriver().getCurrentUrl();
        logAndAssert("User verifies Taxonomy Home Page URL", tAXonomyHomePageURL, taxonomyHomeUrl, AssertType.EQUALS);
    }
}
