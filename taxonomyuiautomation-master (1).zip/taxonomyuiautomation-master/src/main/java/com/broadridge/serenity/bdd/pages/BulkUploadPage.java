package com.broadridge.serenity.bdd.pages;


import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class BulkUploadPage extends PageObject {
    public String begXpath = "//div[@id=\"div";
    public String endXpathRadioBtns = "\"]//table[@class=\"tbl\"]/tbody/tr/td/input";
    public String endXpathTempNames = "\"]//table[@class=\"tbl\"]/tbody/tr/td[@style]";
    public String endXpathDlLinks = "\"]//table[@class=\"tbl\"]/tbody/tr/td/a";
    public String partialXpath = "//a[@href=\"#div";
    public String begVariableXpathRadioBtns = "//*[contains(text(),\"";
    public String endVariableXpathRadioBtns = "\")]/../descendant::input";
    public String Browse = "ctl00_ctl00_MainContent_MainContent_fileUpload";
    public String uploadSuccess = "//*[contains(text(),'";

    @FindBy(xpath = "//span[text()=\"Browse\"]")
    public WebElementFacade BrowseBtn;

    @FindBy(xpath = "//input[@type=\"submit\" and @value=\"Upload\"]")
    public WebElementFacade UploadBtn;
}
