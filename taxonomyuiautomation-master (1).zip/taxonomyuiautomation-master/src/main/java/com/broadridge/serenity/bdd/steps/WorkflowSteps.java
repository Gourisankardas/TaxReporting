package com.broadridge.serenity.bdd.steps;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.WorkflowPage;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;


public class WorkflowSteps {

    @Steps
    WorkflowPage workflowPage;

    @Step
    public void verifyCusipFieldIsPresent() {
        logAndAssert("User verifies if CUSIP field is present", true, workflowPage.cusip.isPresent(), AssertType.EQUALS);
    }

    public void verifyCollapseAllButtonIsPresent() {
        logAndAssert("User verifies if Collapse All button is present", true, workflowPage.collapseAll.isPresent(), AssertType.EQUALS);
    }

    public void verifyExpandAllButtonIsPresent() {
        logAndAssert("User verifies if Expand All button is present", true, workflowPage.expandAllBtn.isPresent(), AssertType.EQUALS);
    }
}
