package com.broadridge.serenity.bdd.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class ChangeHistoryPage extends PageObject {

    @FindBy(xpath = "//div/fieldset/p/input[contains(@id,'CUSIP')]")
    public WebElementFacade CUSIP;

    @FindBy(xpath = "//div/fieldset/p/input[contains(@id,'fromdate')]")
    public WebElementFacade fromDate;

    @FindBy(xpath = "//div/fieldset/p/input[contains(@id,'todate')]")
    public WebElementFacade toDate;
}

