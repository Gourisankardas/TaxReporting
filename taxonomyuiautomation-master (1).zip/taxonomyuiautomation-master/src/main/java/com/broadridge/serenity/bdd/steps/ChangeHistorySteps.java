package com.broadridge.serenity.bdd.steps;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.ChangeHistoryPage;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;

public class ChangeHistorySteps extends ScenarioSteps {

    @Steps
    ChangeHistoryPage changeHistoryPage;

    @Step
    public void verifyFromDateFieldIsPresent() {
        logAndAssert("User verifies if From Date field is Present", true, changeHistoryPage.fromDate.isDisplayed(), AssertType.EQUALS);
    }

    public void verifyToDateFieldIsPresent() {
        logAndAssert("User verifies if To Date field is Present", true, changeHistoryPage.toDate.isDisplayed(), AssertType.EQUALS);
    }
}
