package com.broadridge.serenity.bdd.steps;


import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.OidPage;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;
import static com.broadridge.serenity.bdd.pages.OidPage.oidHomePageURL;


public class OidSteps extends ScenarioSteps {
    @Steps
    OidPage oidPage;

    @Step
    public void enterCUSIP(String userCusip) {
        oidPage.cusip.waitUntilEnabled().sendKeys(userCusip);
    }

    @Step
    public void clickOnGOButton() {
        oidPage.oidGo.waitUntilClickable().click();
    }

    @Step
    public void verifyCurrentOidType(String oldOidType, String cusipNo) {
        String actualOldOidType = oidPage.oidList.select().getFirstSelectedOption().getText();
        logAndAssert("User checks Current oid type of CUSIP "+cusipNo+" from webPage", oldOidType, actualOldOidType, AssertType.EQUALS);
    }

    @Step
    public void chooseOid(String userOidType) {
        oidPage.oidGo.waitUntilPresent();
        oidPage.oidList.waitUntilEnabled().selectByVisibleText(userOidType);
        waitABit(1000);
    }

    @Step
    public void clickOnOIDMenu() {
        verifyUserIsOnOidPage();
        oidPage.oidList.waitUntilClickable().click();
    }

    @Step
    public void clickSaveChangesButton() {
        oidPage.oidSaveChanges.waitUntilEnabled().click();
        waitABit(2000);
    }

    @Step
    public void verifyUserIsOnOidPage() {
        waitABit(15000);
        String currentUrl = getDriver().getCurrentUrl();
        logAndAssert("User checks if Current page is OID Page", oidHomePageURL, currentUrl, AssertType.EQUALS);
    }

    @Step
    public void verifyAndClearCUSIPSearchField() {
        oidPage.getDriver().navigate().refresh();
        oidPage.cusip.waitUntilClickable();
        oidPage.cusip.waitUntilEnabled().clear();
    }
}
