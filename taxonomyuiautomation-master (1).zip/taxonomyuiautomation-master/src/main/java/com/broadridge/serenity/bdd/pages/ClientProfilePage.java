package com.broadridge.serenity.bdd.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

public class ClientProfilePage extends PageObject {

    public static final String clientProfileHomePageURL = "https://icsqa-taxonomy.broadridge.net/Admin/ClientOptions.aspx";

    @FindBy(xpath = "//a[contains(text(),'Add Client Profile')]")
    public WebElementFacade lnkAddprofile;

}
