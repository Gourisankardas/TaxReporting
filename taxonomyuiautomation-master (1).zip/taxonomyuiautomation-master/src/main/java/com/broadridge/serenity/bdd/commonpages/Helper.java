package com.broadridge.serenity.bdd.commonpages;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.enums.EnvironmentType;
import com.broadridge.serenity.bdd.enums.Formatters;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import net.serenitybdd.core.Serenity;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.hamcrest.text.IsEqualIgnoringCase;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.*;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.hamcrest.Matchers.contains;
import static org.hamcrest.Matchers.containsInAnyOrder;
import static org.hamcrest.text.MatchesPattern.matchesPattern;
import static org.junit.Assert.assertThat;


public class Helper {
    public Helper() {
    }

    public static final String CONSTANT1 = "abc";


    public synchronized static List<String> findMatches(String stringToSearchIn, String regEx) {
        List<String> allMatches = new ArrayList<>();
        Pattern pattern = Pattern.compile(regEx);
        Matcher matcher = pattern.matcher(stringToSearchIn);
        while (matcher.find()) {
            allMatches.add(replaceMultiple(matcher.group().trim(), "", "#!#", "['", "']"));
        }
        return allMatches;
    }

    public synchronized static String replaceMultiple(String stringToSearchIn, String replaceWith, String... replaceTo) {
        if (replaceTo.length == 0) {
            return stringToSearchIn;
        } else {
            for (int i = 0; i < replaceTo.length; i++) {
                stringToSearchIn = stringToSearchIn.replace(replaceTo[i], replaceWith);
            }
        }
        return stringToSearchIn;
    }

    public synchronized static String runWinProcess(String command) {
        StringBuilder builder = new StringBuilder();
        try {
            Process p = Runtime.getRuntime().exec(command);
            BufferedReader stdInput = new BufferedReader(new InputStreamReader(p.getInputStream()));
            BufferedReader stdError = new BufferedReader(new InputStreamReader(p.getErrorStream()));

            // read the output from the command
            String s;
            while ((s = stdInput.readLine()) != null) {
                System.out.println(s);
                builder.append(s).append(System.lineSeparator());
            }

            // read any errors from the attempted command
            while ((s = stdError.readLine()) != null) {
                System.out.println(s);
            }
        } catch (IOException e) {
            System.out.println("exception happened - here's what I know: ");
            e.printStackTrace();
            System.exit(-1);
        }
        return builder.toString();
    }

    public synchronized static String readFileAsString(String filePath) {
        try {
            return FileUtils.readFileToString(new File(filePath), StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.out.println("Could not read files");
            e.printStackTrace();
        }
        return null;
    }

    public synchronized static LinkedHashMap<Object, Object> jsonToMap(String json) {
        try {
            return new ObjectMapper().readValue(json, LinkedHashMap.class);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return null;
    }

    public synchronized static LinkedHashMap<String, String> jsonToMapString(String json) throws IOException {
        return new ObjectMapper().readValue(json, LinkedHashMap.class);
    }


    public synchronized static String mapToJson(Object map) throws IOException {
        return new ObjectMapper().writeValueAsString(map);
    }

    public synchronized static Integer generateRandomNumber(int length) {
        return (int) (Math.random() * length);
    }

    public static synchronized boolean compareImage(String imagePathA, String imagePathB, float tolerancePercent) throws FileNotFoundException {
        File fileA = new File(imagePathA);
        File fileB = new File(imagePathB);
        float percentage = 0;
        if (fileA.exists() && fileB.exists()) {
            try {
                BufferedImage biA = ImageIO.read(fileA);
                DataBuffer dbA = biA.getData().getDataBuffer();
                int sizeA = dbA.getSize();
                BufferedImage biB = ImageIO.read(fileB);
                DataBuffer dbB = biB.getData().getDataBuffer();
                int sizeB = dbB.getSize();
                int count = 0;

                if (sizeA == sizeB) {
                    for (int i = 0; i < sizeA; i++) {
                        if (dbA.getElem(i) == dbB.getElem(i)) {
                            count = count + 1;
                        }
                    }
                    percentage = (count * 100) / sizeA;
                } else {
                    System.out.println("Both the images are not of same size");
                }

            } catch (Exception e) {
                System.out.println("Failed to compare image files ...");
            }
        } else {
            throw new FileNotFoundException("File not found in the given path ...");
        }
        System.out.println("Percentage of similarity between the images is " + percentage + "%");
        return percentage >= tolerancePercent;
    }

    public static synchronized List<String> getRegexMatches(String textToSearchIn, String regexPattern) {
        List<String> allMatches = new ArrayList<>();
        Pattern pattern = Pattern.compile(regexPattern);
        Matcher matcher = pattern.matcher(textToSearchIn);
        while (matcher.find()) {
            allMatches.add(matcher.group().trim());
        }
        return allMatches;
    }

    public static synchronized String removeMultipleSpaces(String input) {
        return input.replaceAll("\\s+", " ");
    }

    public static synchronized String removeNonASCIIChars(String input) {
        return input.replaceAll("[^\\x20-\\x7e]", " ");
    }

    public static synchronized String formatString(String input, Formatters formatters, String... args) {
        switch (formatters) {
            case PHONENUMBER:
                return input.trim().replaceFirst("(\\d{3})(\\d{3})(\\d+)", "($1) $2-$3");
            case REPLACEMENTS:
                if (args.length == 0) {
                    throw new IndexOutOfBoundsException("No replacement values were provided to be replaced in the string: " + input);
                }
                return String.format(input, args);
            default:
                return input;
        }
    }

    public static synchronized String formatDate(String date, String fromFormat, String toFormat) {
        try {
            return formatDate(parseDate(date, fromFormat), toFormat);
        } catch (ParseException e) {
            System.out.printf("Failed to parse date: %s with format: %s", date, fromFormat);
        }
        return null;
    }

    private static String formatDate(Date parseDate, String toFormat) {
        return new SimpleDateFormat(toFormat).format(parseDate);
    }

    private static Date parseDate(String date, String fromFormat) throws ParseException {
        return new SimpleDateFormat(fromFormat).parse(date);
    }

    public static String getTodaysDate(String format) {
        return new SimpleDateFormat(format).format(new Date());
    }

    public static String getTodaysDate(String format, String timeZone) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
        return simpleDateFormat.format(new Date());
    }

    public static Object readProperty(String propertyName, EnvironmentType environmentType) {
        switch (environmentType) {
            case SERENITY:
                if (Serenity.sessionVariableCalled(propertyName) != null) {
                    return Serenity.sessionVariableCalled(propertyName);
                } else {
                    System.out.println("Reading property from Serenity session variable failed for property: " + propertyName);
                    return null;
                }
            case SYSTEM:
                if (System.getProperty(propertyName) != null) {
                    return System.getProperty(propertyName);
                } else {
                    System.out.println("Reading property from System property failed for property key: " + propertyName);
                    return null;
                }
            default:
                return null;
        }
    }

    public static <T> T readProperty(String propertyName, EnvironmentType environmentType, Class<T> clazz) {
        switch (environmentType) {
            case SERENITY:
                if (Serenity.sessionVariableCalled(propertyName) != null) {
                    return clazz.cast(Serenity.sessionVariableCalled(propertyName));
                } else {
                    System.out.println("Reading property from Serenity session variable failed for property: " + propertyName);
                    return null;
                }
            case SYSTEM:
                if (System.getProperty(propertyName) != null) {
                    return (T) System.getProperty(propertyName);
                } else {
                    System.out.println("Reading property from System property failed for property key: " + propertyName);
                    return null;
                }
        }
        return null;
    }

    public static Boolean writeProperty(String propertyName, Object propertyValue, EnvironmentType environmentType) {
        if (propertyValue != null && propertyName != null && !propertyName.isEmpty()) {
            switch (environmentType) {
                case SERENITY:
                    Serenity.setSessionVariable(propertyName).to(propertyValue);
                    return true;
                case SYSTEM:
                    if (propertyValue instanceof String) {
                        System.setProperty(propertyName, propertyValue.toString());
                        return true;
                    } else {
                        System.out.println("Writing property to System property failed because the provided value is not string type");
                        return false;
                    }
                default:
                    return null;
            }
        } else {
            System.out.println("Property name or value was blank or null");
            return false;
        }
    }

    public synchronized static void loadProperties(String filePath) throws IOException {
        Properties properties = new Properties();
        properties.load(new FileReader(filePath));
        for (String propertyName : properties.stringPropertyNames()) {
            writeProperty(propertyName, properties.getProperty(propertyName), EnvironmentType.SYSTEM);
        }
    }

    //UI Helper elements
    public synchronized static Color getColorForWebElement(WebElement element) {
        List<String> color = getRegexMatches(element.getCssValue("color"), "(\\d)");
        return new Color(Integer.parseInt(color.get(0)), Integer.parseInt(color.get(1)), Integer.parseInt(color.get(2)));
    }

    public synchronized static String getTrailingTextWithLength(String text, int length) {
        if (text.length() > length) {
            return text.substring(text.length() - 10, text.length());
        } else {
            return text;
        }
    }

    public synchronized static String formatCurrency(String formattedCurrencyAsText) {
        String format = formattedCurrencyAsText.replaceAll("[$,]", "");
        return format.equals("0") ? "0.00" : (format.contains(".") ? format : format + ".00");
    }

    //delete file
    public static void deleteLocalFile(String filePath) {
        try {
            Files.delete(Paths.get(filePath));
        } catch (IOException e) {
            System.out.println("File at --> " + filePath + " <--could not be deleted");
        }
    }

    public static void logAndAssert(String message, Object expected, Object actual, AssertType assertType, String... type) {
        try {
            Class<?> aClass = Class.forName(Thread.currentThread().getStackTrace()[2].getClassName());
            Logger logger = Logger.getLogger(aClass.getName());
            logger.info(message);
            // Serenity.takeScreenshot();
            switch (assertType) {
                case SIZE:
                    Serenity.reportThat(message, () -> Assert.assertTrue(actual == expected));
                    break;
                case CONTAINS:
                    Serenity.reportThat(message, () -> Assert.assertTrue(actual.toString().contains(expected.toString())));
                    break;
                case EQUALS:
                    Serenity.reportThat(message, () -> {
                        if (type.length > 0) {
                            if (type[0].equals("STRING")) {
                                Assert.assertEquals(type[0], actual.toString(), expected.toString());
                            }
                        } else if (NumberUtils.isCreatable(expected.toString()) && NumberUtils.isCreatable(actual.toString())) {
                            Assert.assertEquals(Double.parseDouble(actual.toString()), Double.parseDouble(expected.toString()), 0.02);
                        } else {
                            Assert.assertEquals(actual, expected);

                        }
                        Assert.assertEquals(actual, expected);
                    });
                    break;
                case MATCHESREGEX:
                    Serenity.reportThat(message, () -> Assert.assertThat(message, actual.toString(), matchesPattern(expected.toString())));
                    break;
                case NOTEQUALS:
                    Serenity.reportThat(message, () -> Assert.assertNotEquals(actual, expected));
                    break;
                case EQUALSIGNORECASE:
                    Serenity.reportThat(message, () -> assertThat(message, actual.toString(), IsEqualIgnoringCase.equalToIgnoringCase(expected.toString())));
                    break;
                case LISTARRAYEQUALS:
                    List<String[]> actual1 = (List<String[]>) actual;
                    List<String[]> expected1 = (List<String[]>) expected;
                    Serenity.reportThat(message, () -> assertThat(message, actual1, containsInAnyOrder(expected1.toArray())));
                    Serenity.reportThat(message, () -> assertThat(message, actual1, contains(expected1.toArray())));

                    break;

            }
            Serenity.recordReportData().withTitle("Expected").andContents(expected.toString());
            Serenity.recordReportData().withTitle("Actual").andContents(actual.toString());

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }


/*

    public static void main(String[] args) {

        System.out.println(getTodaysDate("MM/dd/YY"));
        List<String> cusipDetailLabels = new ArrayList<>(Arrays.asList("Cusip","Sedol", "Ticker", "Status", "EffectiveDate", "DeletionDate", "Description", "ISIN", "SecTypeCode", "BPSID", "RecordEndDate"));
        System.out.println(cusipDetailLabels);
        System.out.println(cusipDetailLabels.toString());

        String[] arr = cusipDetailLabels.toArray(new String[0]);
        String[] arr1 = cusipDetailLabels.stream().toArray(String[] ::new);

        List<String> arr2 = Arrays.asList(arr);
    }

*/


}
