package com.broadridge.serenity.bdd.steps;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.AdminSharedPage;
import com.broadridge.serenity.bdd.pages.DashboardPage;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;

public class DashboardSteps extends ScenarioSteps {
    @Steps
    DashboardPage dashboardPage;
    @Steps
    AdminSharedPage adminSharedPage;

    @Step
    public void dropdownOptions(String dropdownOption) {
        dashboardPage.source.waitUntilEnabled().selectByVisibleText(dropdownOption);
    }

    @Step
    public void verifyColumns(String rowCount, String columnNames) {
        if (!rowCount.equals("0")) {
            List<String> expectedColumnText = new ArrayList<>(Arrays.asList(columnNames.split(":")));
            List<String> actualColTxt = new ArrayList<>();
            logAndAssert("User checks Taxonomy: column headers size", expectedColumnText.size(), dashboardPage.columns.size(), AssertType.SIZE);
            for (WebElementFacade e : dashboardPage.columns) {
                actualColTxt.add(e.getText());
            }
            logAndAssert("User checks Taxonomy: column headers(texts/values)", expectedColumnText, actualColTxt, AssertType.LISTARRAYEQUALS);
        }
    }

    @Step
    public void verifyCalendarInputFieldsIsPresent() {
        logAndAssert("User verifies if Start Date field is Present", true, adminSharedPage.startDate.isDisplayed(), AssertType.EQUALS);
        logAndAssert("User verifies if End Date field is Present", true, adminSharedPage.endDate.isDisplayed(), AssertType.EQUALS);
    }

    @Step
    public void clickFilterButton() {
        dashboardPage.filterButton.waitUntilClickable().click();
    }

    @Step
    public void verifyFirstSource(String option, String rowNum) {
        if (option.equals("All")) {
            logAndAssert("User skips check", "All", option, AssertType.EQUALS);
        } else if (rowNum.equals("0")) {
            logAndAssert("User skips check", "0", rowNum, AssertType.EQUALS);
        } else {
            String actualColName = dashboardPage.firstSource.getText();
            logAndAssert("User checks if Taxonomy: Source Column(expected) matches filter(actual)", option, actualColName, AssertType.EQUALS);
        }

    }
}
