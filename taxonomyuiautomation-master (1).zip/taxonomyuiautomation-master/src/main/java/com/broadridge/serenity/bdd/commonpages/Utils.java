package com.broadridge.serenity.bdd.commonpages;

import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import java.io.*;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Properties;


public class Utils extends ScenarioSteps {
    static File file;


    @Step("user validates whether the given field is empty {0}")
    public static boolean verifyFieldIsEmpty(WebElementFacade webElement) {
        String fieldName = webElement.getText();
        return fieldName.isEmpty();
    }

    @Step("Utility function to enter date and exceed days {0}")
    public static String enterDate(int days) {
        SimpleDateFormat sdf = new SimpleDateFormat("M/dd/yyyy");
        Calendar c = Calendar.getInstance();
        c.setTime(new Date()); // Using today's date
        c.add(Calendar.DATE, days); // Adding 5 days
        //if ((day != Calendar.SATURDAY) && (day != Calendar.SUNDAY))
        String recordDate = sdf.format(c.getTime());
        System.out.println(recordDate);
        return recordDate;
    }

    @Step("user enter enclosure page dates")
    public static String enterEnclosurePageDatesExcludingWeekends() {
        LocalDate input = LocalDate.now();
        LocalDate result = addDaysSkippingWeekends(input, 15);
        String resultDate = result.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        System.out.println(resultDate);
        return resultDate;

    }

    @Step("Utility function to enter Meeting date excluding weekend")
    public static String enterMeetingDateExcludingWeekends() {
        LocalDate input = LocalDate.now();
        LocalDate result = addDaysSkippingWeekends(input, 261);
        String resultDate = result.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        System.out.println(resultDate);
        return resultDate;

    }

    @Step("Utility function to enter Material date excluding weekend")
    public static String enterNcfDateExcludingWeekends() {
        LocalDate input = LocalDate.now();
        LocalDate result = addDaysSkippingWeekends(input, 10);
        String resultDate = result.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        System.out.println(resultDate);
        return resultDate;

    }

    @Step("Utility function to enter date excluding weekend and exceed day {0}")
    public static String enterDatesExcludingWeekends(int i) {
        LocalDate input = LocalDate.now();
        LocalDate result = addDaysSkippingWeekends(input, 15);
        String resultDate = result.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        System.out.println(resultDate);
        return resultDate;
    }

    @Step("Utility function to enter date excluding weekend")
    public static String enterDateExcludingWeekends() {
        LocalDate input = LocalDate.now();
        LocalDate result = addDaysSkippingWeekends(input, 2);
        String resultDate = result.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        System.out.println(resultDate);
        return resultDate;

    }

    @Step("Utility function to enter date excluding weekend")
    public static String enterFromDateExcludingWeekends() {
        LocalDate input = LocalDate.now();
        LocalDate result = addDaysSkippingWeekends(input, 0);
        String resultDate = result.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        System.out.println(resultDate);
        return resultDate;

    }

    @Step("Utility function to enter date excluding weekend")
    public static String enterToDateExcludingWeekends() {
        LocalDate input = LocalDate.now();
        LocalDate result = addDaysSkippingWeekends(input, 3);
        String resultDate = result.format(DateTimeFormatter.ofPattern("MM/dd/yyyy"));
        System.out.println(resultDate);
        return resultDate;

    }

    @Step("Utility function to enter date excluding weekend using local date {0} and exceed day{1}")
    public static LocalDate addDaysSkippingWeekends(LocalDate date, int days) {
        LocalDate result = date;
        int addedDays = 0;
        while (addedDays < days) {
            result = result.plusDays(1);
            if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY || result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
                ++addedDays;
            }
        }
        return result;
    }

    public static void uploadFile(String path, WebElementFacade element) {
        File file = new File(path);
        element.sendKeys(file.getAbsolutePath());
    }


    public static void mouseHover(WebDriver driver, WebElementFacade webElement) {
        Actions action = new Actions(driver);
        action.moveToElement(webElement).build().perform();
    }

    @Step("save to Properties file")
    static void saveProperties(Properties p) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(file, true);
        p.store(fileOutputStream, "Properties");
        fileOutputStream.close();
        //System.out.println("After saving properties: " + p);
    }

    @Step("Load into properties file")
    static void loadProperties(Properties p) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(file);
        p.load(fileInputStream);
        fileInputStream.close();
        //System.out.println("After Loading properties: " + p);
    }

    @Step("Write to properties file from web page as key value pair")
    public static void writeFile(String key, String value) throws IOException {
        file = new File("src/test/resources/files/campaign.properties");
        Properties data = new Properties();
        data.setProperty(key, value);
        saveProperties(data);
        loadProperties(data);
    }

    @Step("Read data from properties file")
    public static Properties readPropertyFile() throws IOException {
        FileInputStream fileInputStream;
        Properties prop = null;
        try {
            fileInputStream = new FileInputStream("src/test/resources/files/campaign.properties");
            prop = new Properties();
            prop.load(fileInputStream);
        } catch (FileNotFoundException fileNotFoundException) {
            fileNotFoundException.printStackTrace();
        }
        return prop;
    }

    public static void uploadFileICSDirect(String path, WebElement element) {
        File file = new File(path);
        element.sendKeys(file.getAbsolutePath());
    }

    public static void deleteFile(String filename) {
        // String home = System.getProperty("user.home");
        String file_name = filename;
        String file_with_location = "src/test/resources/files/" + file_name;
        System.out.println("Function Name ===========================src/test/resources/files/" + file_name);
        File file = new File(file_with_location);
        if (file.exists()) {
            System.out.println(file_with_location + " is present");
            if (file.delete()) {
                System.out.println("file deleted");
            } else {
                System.out.println("file not deleted");
            }
        } else {
            System.out.println(file_with_location + " is not present");
        }
    }
}

