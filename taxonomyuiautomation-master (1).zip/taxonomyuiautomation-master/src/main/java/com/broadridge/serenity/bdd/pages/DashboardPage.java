package com.broadridge.serenity.bdd.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import java.util.List;


public class DashboardPage extends PageObject {

    @FindBy(xpath = "//select[@id=\"ctl00_ctl00_MainContent_MainContent_ddlStatusFilter\"]")
    public WebElementFacade source;

    @FindBy(xpath = "//tr[@class=\"headerNoSort\"]/th")
    public List<WebElementFacade> columns;

    @FindBy(xpath = "(//span[contains(@id,'Source')])[1]")
    public WebElementFacade firstSource;

    @FindBy(xpath = "//input[@type='submit' and @value='Filter']")
    public WebElementFacade filterButton;

    @FindBy(xpath = " //button[contains(text(),'Done')]")
    public WebElementFacade done;

}
