package com.broadridge.serenity.bdd.pages;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class CrEligibilityPage extends PageObject {

    public static final String crEligibilityHomePageURL = "https://icsqa-taxonomy.broadridge.net/Admin/ConstructiveReceiptEligibility.aspx";

    @FindBy(xpath = "//tr[@style=\"display: table-row;\"]/td[1]")
    public List<WebElementFacade> secTypes;

    @FindBy(xpath = "//tr[@style=\"display: table-row;\"]/td[2]")
    public List<WebElementFacade> descs;

    @FindBy(xpath = "//tr[@style=\"display: table-row;\"]/td[3]")
    public List<WebElementFacade> checkboxes;
}
