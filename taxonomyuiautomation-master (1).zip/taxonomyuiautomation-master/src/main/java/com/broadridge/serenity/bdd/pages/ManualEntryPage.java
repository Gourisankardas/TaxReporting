package com.broadridge.serenity.bdd.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;

import java.util.List;

public class ManualEntryPage extends PageObject {
    public String partialXpath = "//div[@class=\"ui-tabs ui-widget ui-widget-content ui-corner-all\"]//span[text()='";

    @FindBy(xpath = "//fieldset/div/p/input[contains(@id,'CusipDetails') and not(contains(@type,'hidden'))]")
    public List<WebElementFacade> cusipDetailInputs;

    @FindBy(xpath = "//input[contains(@id,'Cusip') and @type=\"text\" and @maxlength=\"9\"]")
    public WebElementFacade cusipInput;

    @FindBy(xpath = "//input[contains(@id,'CusipDetails') and @maxlength=12 or @maxlength=300]")
    public List<WebElementFacade> otherTxtFields;

    @FindBy(xpath = "//input[contains(@id,'EffectiveDate')]")
    public WebElementFacade effectiveDateInput;

    @FindBy(xpath = "//input[contains(@id,'DeletionDate')]")
    public WebElementFacade deletionDateInput;

    @FindBy(xpath = "//input[contains(@id,'EndDate')]")
    public WebElementFacade endDateInput;

    @FindBy(xpath = "//input[contains(@id,'BPSID')]")
    public WebElementFacade bpsId;

    @FindBy(xpath = "//div[contains(@id,'General')]/fieldset/legend")
    public WebElementFacade cusipDetails;

    @FindBy(xpath = "//li[contains(@id,'MainContent')]/a")
    public List<WebElementFacade> tabHeaders;

    @FindBy(xpath = "//div[@id=\"ctl00_ctl00_MainContent_MainContent_fvCusipDetails_pnlHeader\"]//label")
    public List<WebElementFacade> yearEndLabels;

    @FindBy(xpath = "//div[@id=\"ctl00_ctl00_MainContent_MainContent_fvCusipDetails_pnlCusipInfo\"]//label")
    public List<WebElementFacade> secInfoLabels;

    @FindBy(xpath = "//div[@id=\"ctl00_ctl00_MainContent_MainContent_fvCusipDetails_pnlHeader\"]//input[contains(@id,'MainContent_fvCusipDetails_txt') and not(@type=\"hidden\")]")
    public List<WebElementFacade> yearEndInputs;

    @FindBy(xpath = "//div[@id=\"ctl00_ctl00_MainContent_MainContent_fvCusipDetails_pnlCusipInfo\"]//input[contains(@id,'MainContent_fvCusipDetails') and @type=\"text\" and not(@type=\"hidden\")]")
    public List<WebElementFacade> secInfoInputs;

    @FindBy(xpath = "//input[contains(@name,'TaxationCountry') and @type=\"text\"]")
    public WebElementFacade taxationCountryInput;

    @FindBy(xpath = "//a[@id=\"ctl00_ctl00_MainContent_MainContent_fvCusipDetails_lbtnAddCusip\"]")
    public WebElementFacade lnkCusipLink;

    @FindBy(xpath = "//div[@id=\"ctl00_ctl00_MainContent_MainContent_fvCusipDetails_pnlHeader\"]//span[@class=\"lookupimg\"]")
    public List<WebElementFacade> yearEndSpans;

    @FindBy(xpath = "//div[@id=\"ctl00_ctl00_MainContent_MainContent_fvCusipDetails_pnlCusipInfo\"]//span[@class=\"lookupimg\"]")
    public List<WebElementFacade> secInfoSpans;

    @FindBy(xpath = "//input[@name=\"ctl00$ctl00$MainContent$MainContent$fvCusipDetails$txtModifiedOnDate\"]")
    public WebElementFacade yearEndDateNotification;

    @FindBy(xpath = "//input[@name=\"ctl00$ctl00$MainContent$MainContent$fvCusipDetails$Label23\"]")
    public WebElementFacade secInfoSpecialNoticeTxt;

    @FindBy(xpath = "//input[@name=\"ctl00$ctl00$MainContent$MainContent$fvCusipDetails$txtMaterialModificationDocLink\"]")
    public WebElementFacade secInfoDocLink;

    @FindBy(xpath = "//input[@name=\"ctl00$ctl00$MainContent$MainContent$fvCusipDetails$txtProspectusLink\"]")
    public WebElementFacade secInfoProLink;

    @FindBy(xpath = "//div[@class=\"infobox\"]/span[text()=\"Data Saved\" or text()=\"Data saved\"]")
    public WebElementFacade msgBoxTxt;

    @FindBy(xpath = "//div[@class=\"infobox\" and starts-with(@style,'overflow')]//a")
    public WebElementFacade msgBoxClose;

    @FindBy(xpath = "//div[@id=\"divNewTaxYear\"]/p/label")
    public WebElementFacade enterTaxYrLabel;

    @FindBy(xpath = "//input[@id=\"txtNewTaxYear\"]")
    public WebElementFacade taxYear;

    @FindBy(xpath = "//span[text()=\"Ok\"]")
    public WebElementFacade taxYrOkBtn;

    @FindBy(xpath = "//select[starts-with(@data-bind,'options:$parent.serviceCodes')]")
    public WebElementFacade tdsServiceCd;

    @FindBy(xpath = "//input[@name=\"ko_unique_1\"]")
    public WebElementFacade startDate;

    @FindBy(xpath = "//input[@name=\"ko_unique_2\"]")
    public WebElementFacade endDate;

    @FindBy(xpath = "//div[@id=\"editMode\"]/table/thead/tr/th[text()=\"End Date\"]")
    public WebElementFacade endDateHeader;

    @FindBy(xpath = "//div[@id=\"readonlyMode\"]//thead[@class=\"headerNoSort\"]//th")
    public List<WebElementFacade> tdsCodesHeader;

    @FindBy(xpath = "//div[@id=\"readonlyMode\"]//tbody/tr/td")
    public List<WebElementFacade> tdsCodesSavedEntries;

    @FindBy(xpath = "//*[@value='Add']")
    public WebElementFacade add;

    @FindBy(xpath = "//span[contains(text(),'Add')]/parent::span/..")
    public WebElementFacade addButtonTdsCodes;

    @FindBy(xpath = "//*[@value='Save']")
    public WebElementFacade save;

    @FindBy(xpath = "(//input[@type='submit' and @value='Edit'])[2]")
    public WebElementFacade edit;

    @FindBy(xpath = "//label[contains(text(),'Status')]/../input[@type='text']")
    public WebElementFacade statusField;

    @FindBy(xpath = "//label[contains(text(),'Security Type')]/../input[@type='text']")
    public WebElementFacade securityTypeField;

    @FindBy(xpath = "//*[text()='Edit']")
    public WebElementFacade edit1;
}
