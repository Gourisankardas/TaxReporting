package com.broadridge.serenity.bdd.steps;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.BulkUploadPage;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.springframework.util.FileSystemUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;


public class BulkUploadSteps extends ScenarioSteps {

    @Steps
    BulkUploadPage bulkUploadPage;

    @Step("Taxonomy Verify Selected Tab {0}")
    public void verifySelectedTab(String selectTab) {
        WebElementFacade e = bulkUploadPage.$(By.xpath(bulkUploadPage.partialXpath + selectTab + "\"]/.."));
        e.waitUntilClickable().click();
        String actualTabStatus = e.getAttribute("aria-selected");
        logAndAssert("User verifies Selected Tab :" + selectTab + " status", "true", actualTabStatus, AssertType.EQUALS);
    }

    @Step("User tries to verify & download Bulk upload templates")
    public void verifyTemplatesAndDownload(String tabName2, String templateNames) {
        List<String> userInputNames = new ArrayList<>(Arrays.asList(templateNames.split(";")));
        List<WebElementFacade> getNames = bulkUploadPage.$$(By.xpath(bulkUploadPage.begXpath + tabName2 + bulkUploadPage.endXpathTempNames));
        List<WebElementFacade> getRadioBtns = bulkUploadPage.$$(By.xpath(bulkUploadPage.begXpath + tabName2 + bulkUploadPage.endXpathRadioBtns));
        List<WebElementFacade> getDlTmpLinks = bulkUploadPage.$$(By.xpath(bulkUploadPage.begXpath + tabName2 + bulkUploadPage.endXpathDlLinks));

        for (int i = 0; i < userInputNames.size(); i++) {
            logAndAssert("User verifies if Template " + userInputNames.get(i) + "is present", userInputNames.get(i), getNames.get(i).getText(), AssertType.EQUALS);
            logAndAssert("User verifies if " + userInputNames.get(i) + "radio button is displayed", true, getRadioBtns.get(i).isDisplayed(), AssertType.EQUALS);
            logAndAssert("User verifies if " + userInputNames.get(i) + "template link is displayed", true, getDlTmpLinks.get(i).isDisplayed(), AssertType.EQUALS);
            getDlTmpLinks.get(i).waitUntilClickable().click();
        }
    }

    @Step
    public void browseButtonEnabled() {
        logAndAssert("User verifies if Taxonomy Bulk Upload 'Browser button' is enabled", true, bulkUploadPage.BrowseBtn.isEnabled(), AssertType.EQUALS);
    }

    @Step
    public void uploadButtonEnabled() {
        logAndAssert("User verifies if Taxonomy Bulk Upload 'Upload button' is enabled", true, bulkUploadPage.UploadBtn.isEnabled(), AssertType.EQUALS);
    }

    @Step
    public void browseAndUploadTemplateAndVerify(String templateFiles, String templateNames, String tabName) {
        List<String> userInputNames = new ArrayList<>(Arrays.asList(templateNames.split(";")));
        List<String> userInputFiles = new ArrayList<>(Arrays.asList(templateFiles.split(";")));
        String Path = "src/test/resources/downloads/actual/";
        for (int i = 0; i < userInputNames.size(); i++) {
            WebElementFacade Tab = bulkUploadPage.$(By.xpath(bulkUploadPage.partialXpath + tabName + "\"]/.."));
            Tab.waitUntilClickable().click();
            WebElementFacade Radiobutton = bulkUploadPage.$(By.xpath(bulkUploadPage.begVariableXpathRadioBtns + userInputNames.get(i) + bulkUploadPage.endVariableXpathRadioBtns));
            Radiobutton.waitUntilClickable().click();
            String fileTemplate = userInputFiles.get(i).replaceAll("Insert_Update_", "File: ");
            bulkUploadPage.upload(Path + userInputFiles.get(i) + ".xlsx").to(bulkUploadPage.find(By.id(bulkUploadPage.Browse)));
            bulkUploadPage.UploadBtn.waitUntilClickable().click();
            WebElementFacade Success = bulkUploadPage.$(By.xpath(bulkUploadPage.uploadSuccess + userInputFiles.get(i) + ".xlsx Uploaded Successfully')]"));
            logAndAssert("User verifies if " + fileTemplate + " uploaded successfully", true, Success.isPresent(), AssertType.EQUALS);
        }
    }

    @Step
    public void deleteDirectory() {
        String Path = "src/test/resources/downloads/actual";
        File file = new File(Path);
        if (file.isDirectory()) {
            File directoryToDelete = new File(Path);
            FileSystemUtils.deleteRecursively(directoryToDelete);
        }
    }
}
