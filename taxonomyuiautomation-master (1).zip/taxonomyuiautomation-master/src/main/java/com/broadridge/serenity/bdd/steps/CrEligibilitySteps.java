package com.broadridge.serenity.bdd.steps;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.CrEligibilityPage;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.openqa.selenium.By;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;


public class CrEligibilitySteps extends ScenarioSteps {
    @Steps
    CrEligibilityPage crEligibilityPage;

    @Step
    public void selectHeader(String headerTab) {
        WebElementFacade selectHeader = crEligibilityPage.$(By.xpath("//a[text()='" + headerTab + "']"));
        selectHeader.waitUntilClickable().click();
    }

    @Step
    public void verifyListOfSECTypesAndDescription(String secType, String desc) {
        List<String> secTypeList = new ArrayList<>(Arrays.asList(secType.split(":")));
        List<String> descList = new ArrayList<>(Arrays.asList(desc.split(":")));

        List<String> a1 = new ArrayList<>();
        List<String> a2 = new ArrayList<>();

        for (int i = 0; i < secTypeList.size(); i++) {
            a1.add(crEligibilityPage.secTypes.get(i).getText());
            a2.add(crEligibilityPage.descs.get(i).getText());
            logAndAssert("", true, crEligibilityPage.checkboxes.get(i).isDisplayed(), AssertType.EQUALS);

          /*  Assert.assertEquals(crEligibilityPage.secTypes.get(i).getText(), secTypeList.get(i));
            Assert.assertEquals(crEligibilityPage.descs.get(i).getText(), descList.get(i));
            Assert.assertTrue(crEligibilityPage.checkboxes.get(i).isDisplayed());*/
        }
        logAndAssert("User verifies the 'list of SEC Types' is present", true, (a1.size() == secTypeList.size() && a1.containsAll(secTypeList) && secTypeList.containsAll(a1)), AssertType.EQUALS);
        logAndAssert("User verifies the 'Descriptions' are present", true, (a2.size() == descList.size() && a2.containsAll(descList) && descList.containsAll(a2)), AssertType.EQUALS);
    }
}
