Input Format ::
Jar Location > java -jar BaseEncodeHelper.jar InputString
InputString -> String To Be Encrypted (Don't Enclose the String in Double-Quotes)

Example ::
Jar Location > java -jar BaseEncodeHelper.jar UserName

Note :: 
1. If Input String contains '&' Symbol then it should be present only at the end of the String
    Invalid InputString :- Test456&12
    Valid InputString :- Test45612&
   
2. < or > Symbols should not exist in the InputString
3. '|' Symbol should not exist in the InputString