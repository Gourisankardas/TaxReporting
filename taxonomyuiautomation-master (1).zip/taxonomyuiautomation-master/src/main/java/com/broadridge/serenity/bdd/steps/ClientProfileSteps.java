package com.broadridge.serenity.bdd.steps;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.ClientProfilePage;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;
import static com.broadridge.serenity.bdd.pages.ClientProfilePage.clientProfileHomePageURL;


public class ClientProfileSteps extends ScenarioSteps {

    @Steps
    ClientProfilePage clientProfilePage;

    @Step
    public void verifyUserLandsOnClientProfilePage() {
        String currentUrl = clientProfilePage.getDriver().getCurrentUrl();
        logAndAssert("User checks if current page is 'Client Profile Page'", clientProfileHomePageURL, currentUrl, AssertType.EQUALS);
    }

    public void verifyAddClientProfileLinkIsPresent() {
        logAndAssert("User verifies if 'Add clent profile link' is present", true, clientProfilePage.lnkAddprofile.isPresent(), AssertType.EQUALS);
    }

    public void clickOnAddClientProfileLink() {
        clientProfilePage.lnkAddprofile.waitUntilClickable().click();
    }
}
