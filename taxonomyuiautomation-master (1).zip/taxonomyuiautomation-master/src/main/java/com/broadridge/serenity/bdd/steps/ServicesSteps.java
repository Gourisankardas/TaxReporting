package com.broadridge.serenity.bdd.steps;

import com.broadridge.serenity.bdd.enums.AssertType;
import com.broadridge.serenity.bdd.pages.ServicesPage;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.openqa.selenium.By;

import static com.broadridge.serenity.bdd.commonpages.Helper.logAndAssert;


public class ServicesSteps extends ScenarioSteps {

    @Steps
    ServicesPage servicesPage;

    @Step
    public void searchClient(String client) {
        servicesPage.ClientInput.waitUntilEnabled().sendKeys(client);
        //servicesPage.ClientAutoFill.waitUntilClickable().click();
    }

    @Step
    public void clientSaved(String client) {
        servicesPage.ClientSelected.waitUntilPresent();
        logAndAssert("User verifies client under Client Services", client, servicesPage.ClientSelected.getText(), AssertType.EQUALS);
    }

    @Step
    public void selectValue(String valueAdd) {
        servicesPage.$(By.xpath("//label[text()='" + valueAdd + "']/../input")).waitUntilClickable().click();
    }

    @Step
    public void verifySaveMsg() {
        servicesPage.SaveMsg.waitUntilPresent();
        logAndAssert("User verifies Save message", "Services saved successfully!", servicesPage.SaveMsg.getText(), AssertType.EQUALS);
    }

    @Step
    public void clickServicesGoButton() {
        servicesPage.servicesGo.waitUntilClickable().click();
    }
}
