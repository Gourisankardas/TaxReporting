package com.broadridge.serenity.bdd.pages;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import org.openqa.selenium.By;

import java.util.List;


public class AdminSharedPage extends PageObject {

    @FindBy(xpath = "//a[contains(text(),'Admin')]")
    public WebElementFacade admin;

    @FindBy(xpath = "//input[contains(@id,'StartDate')]")
    public WebElementFacade startDate;

    @FindBy(xpath = "//input[contains(@id,'EndDate')]")
    public WebElementFacade endDate;

    @FindBy(xpath = "//select[contains(@id,'StatusFilter')]/option")
    public List<WebElementFacade> dropdown;

    @FindBy(xpath = "//input[@type=\"submit\" and not(contains(@value,'Go'))]")
    public List<WebElementFacade> pageButtons;

    @FindBy(xpath = "//input[contains(@id,'ctl00_userControlSearch_txtSearch')]")
    public WebElementFacade globalSearchBox;

    @FindBy(xpath = "//input[@type=\"submit\" and @value='Go']")
    public WebElementFacade goBtn;

    @FindBy(xpath = "//td[text()=\"No records found\"]")
    public WebElementFacade noRecordsMsg;

    @FindBy(xpath = "//span[contains(@id,\"RowCount\")]")
    public WebElementFacade rowCount;

    @FindBy(xpath = "//a[@id=\"ctl00_MainContent_gvCusipSearch_ctl02_hlnkEdit\"]")
    public WebElementFacade searchResultEditLink;


    public WebElementFacade selectPage(String selectPage) {
        return $(By.xpath("//a[contains(text(),'" + selectPage + "')]"));
    }


}
